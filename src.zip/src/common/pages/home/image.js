const Image = {
  banner_sm:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/DDE07490AE187611948CB9F15BE41793.png',
  banner_md:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/55C3FCBAC71BE1055775F873E22D092E.png',
  banner_lg:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/EBA101812FE23E98F37D7EC1F204FC74.png',
  banner_xl:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/25FA1E9B5E49AEBD7CFA3F51816630B6.png',
  adv_item0:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/81B03C0DA3BCB843CF579606BD54DC06.png',
  adv_item1:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/5C672F9A3D83697712651260658811DA.png',
  adv_item2:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/1DEDBB0D47FE70AC39E446D8B9AB6FCE.png',
  exp:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/3AF196CA9B03F9FFAE8A519469FBB6AD.png',
  step0:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/5BBC703C1C9BF16E9B3DBE44E9306EBD.png',
  step1:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/EA5B9697721EAAE780B6A0D18D5F6DE5.png',
  step2:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/0A848CAA0FA942D868854F6F469ADEC1.png',
  step3:
    'https://static.bafang.com/cdn/assets/imgs/MjAyMDQ/F497569D03E57047301DAC9E4CB05207.png',
};
export default Image;
