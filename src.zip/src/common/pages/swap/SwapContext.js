import React from 'react';

const SwapContext = React.createContext(null);

export default SwapContext;
