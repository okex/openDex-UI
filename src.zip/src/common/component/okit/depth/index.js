import Depth from './Depth.js';

const depth = new Depth();

export { Depth, depth };
