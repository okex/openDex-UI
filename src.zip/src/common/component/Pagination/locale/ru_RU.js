export default {
  items_per_page: '/странице',
  jump_to: 'Перейти',
  jump_to_confirm: 'подтвердить',
  page: '',
  prev_page: 'Назад',
  next_page: 'Вперед',
  prev_5: 'Предыдущие 5',
  next_5: 'Следующие 5',
  prev_3: 'Предыдущие 3',
  next_3: 'Следующие 3',
};
