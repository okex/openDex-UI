export default {
  items_per_page: 'تال/ھەر بەت',
  jump_to: 'بەتكە سەكرەش',
  jump_to_confirm: 'مۇقىملاشتۇرۇش',
  page: 'بەت',
  prev_page: 'ئالدىنقى',
  next_page: 'كېيىنكى',
  prev_5: 'ئالدىغا 5 بەت',
  next_5: 'كەينىگە 5 بەت',
  prev_3: 'ئالدىغا 3 بەت',
  next_3: 'كەينىگە 3 بەت',
};
