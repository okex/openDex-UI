import React from 'react';
import Icon from '_src/component/IconLite';
const IconFountUnfold = () => {
  return (
    <Icon
      className="icon-Unfold"
      style={{ fontSize: '14px', marginLeft: '6px' }}
    />
  );
};
export default IconFountUnfold;
