import WatchMedia from './js/WatchMedia';
import getMedia from './js/getMedia';

export { WatchMedia, getMedia };
