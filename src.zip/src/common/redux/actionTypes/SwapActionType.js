const SwapActionType = {
  SETTING_ICON: 'SWAP_SETTING_ICON',
  SETTING: 'SWAP_SETTING',
  ALL: 'SWAP_ALL',
};
export default SwapActionType;
