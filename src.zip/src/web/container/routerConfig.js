import commonRoutes from '_src/container/routerConfig';
export default commonRoutes;
